import json
import logging
import os
from datetime import datetime, timezone

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

CENTRAL_BUCKET = os.environ.get(
    "CENTRAL_BUCKET", "clsa-aws-cloudtrail-381492218357"
)
MEMBER_ROLE_NAME = os.environ.get(
    "MEMBER_ROLE_NAME", "KMSInventoryReadRole"
)
CURRENT_OBJECT_KEY = os.environ.get(
    "CURRENT_OBJECT_KEY", "current/kms-inventory.json"
)
EXTERNAL_ID = os.environ.get("EXTERNAL_ID", "").strip()

# EDIT: start with one account. Add the remaining accounts after validation.
TARGET_ACCOUNTS = [
    {
        "account_id": "REPLACE_WITH_12_DIGIT_ACCOUNT_ID",
        "account_name": "Test-Account",
    }
]

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

AWS_CONFIG = Config(
    retries={"max_attempts": 8, "mode": "adaptive"},
    connect_timeout=10,
    read_timeout=60,
)

STS = boto3.client("sts", config=AWS_CONFIG)
S3 = boto3.client("s3", config=AWS_CONFIG)


def utc_text(value):
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


def empty_record(snapshot_time, account_id, account_name, region, error=None):
    return {
        "snapshot_time": snapshot_time,
        "account_id": account_id,
        "account_name": account_name,
        "region": region,
        "key_id": None,
        "key_arn": None,
        "aliases": [],
        "primary_alias": None,
        "description": None,
        "key_state": None,
        "key_manager": None,
        "key_spec": None,
        "key_usage": None,
        "origin": None,
        "creation_date": None,
        "deletion_date": None,
        "enabled": None,
        "multi_region": None,
        "pending_deletion": None,
        "tags": {},
        "rotation_supported": None,
        "rotation_enabled": None,
        "rotation_period_days": None,
        "next_rotation_date": None,
        "collection_error": error,
    }


def append_error(record, message):
    current = record.get("collection_error")
    record["collection_error"] = f"{current}; {message}" if current else message


def assume_member_role(account_id):
    role_arn = f"arn:aws:iam::{account_id}:role/{MEMBER_ROLE_NAME}"
    request = {
        "RoleArn": role_arn,
        "RoleSessionName": "KMSInventoryCollector",
        "DurationSeconds": 3600,
    }
    if EXTERNAL_ID:
        request["ExternalId"] = EXTERNAL_ID

    credentials = STS.assume_role(**request)["Credentials"]
    return {
        "aws_access_key_id": credentials["AccessKeyId"],
        "aws_secret_access_key": credentials["SecretAccessKey"],
        "aws_session_token": credentials["SessionToken"],
    }


def assumed_client(service_name, region, credentials):
    return boto3.client(
        service_name,
        region_name=region,
        aws_access_key_id=credentials["aws_access_key_id"],
        aws_secret_access_key=credentials["aws_secret_access_key"],
        aws_session_token=credentials["aws_session_token"],
        config=AWS_CONFIG,
    )


def enabled_regions(credentials):
    ec2 = assumed_client("ec2", "us-east-1", credentials)
    response = ec2.describe_regions(AllRegions=False)
    return sorted(
        item["RegionName"]
        for item in response.get("Regions", [])
        if item.get("RegionName")
    )


def alias_map(kms):
    result = {}
    paginator = kms.get_paginator("list_aliases")
    for page in paginator.paginate():
        for item in page.get("Aliases", []):
            key_id = item.get("TargetKeyId")
            name = item.get("AliasName")
            if key_id and name:
                result.setdefault(key_id, []).append(name)
    return {key: sorted(set(value)) for key, value in result.items()}


def all_keys(kms):
    result = []
    paginator = kms.get_paginator("list_keys")
    for page in paginator.paginate():
        result.extend(page.get("Keys", []))
    return result


def key_tags(kms, key_id):
    result = {}
    marker = None
    while True:
        request = {"KeyId": key_id, "Limit": 50}
        if marker:
            request["Marker"] = marker
        response = kms.list_resource_tags(**request)
        for item in response.get("Tags", []):
            tag_key = item.get("TagKey")
            if tag_key:
                result[tag_key] = item.get("TagValue", "")
        if not response.get("Truncated"):
            break
        marker = response.get("NextMarker")
        if not marker:
            break
    return result


def rotation_details(kms, key_id, metadata):
    supported = (
        metadata.get("KeySpec") == "SYMMETRIC_DEFAULT"
        and metadata.get("KeyUsage") == "ENCRYPT_DECRYPT"
        and metadata.get("Origin") == "AWS_KMS"
    )
    if not supported:
        return False, None, None, None, None

    try:
        response = kms.get_key_rotation_status(KeyId=key_id)
        return (
            True,
            response.get("KeyRotationEnabled"),
            response.get("RotationPeriodInDays"),
            utc_text(response.get("NextRotationDate")),
            None,
        )
    except ClientError as error:
        code = error.response.get("Error", {}).get("Code", "Unknown")
        if code in {"UnsupportedOperationException", "KMSInvalidStateException"}:
            return False, None, None, None, None
        return True, None, None, None, f"{code}: {error}"


def collect_key(kms, snapshot_time, account_id, account_name, region, key_id, aliases):
    record = empty_record(snapshot_time, account_id, account_name, region)
    record["key_id"] = key_id
    record["aliases"] = aliases
    record["primary_alias"] = aliases[0] if aliases else None

    try:
        metadata = kms.describe_key(KeyId=key_id)["KeyMetadata"]
        record.update(
            {
                "key_id": metadata.get("KeyId", key_id),
                "key_arn": metadata.get("Arn"),
                "description": metadata.get("Description", ""),
                "key_state": metadata.get("KeyState"),
                "key_manager": metadata.get("KeyManager"),
                "key_spec": metadata.get("KeySpec"),
                "key_usage": metadata.get("KeyUsage"),
                "origin": metadata.get("Origin"),
                "creation_date": utc_text(metadata.get("CreationDate")),
                "deletion_date": utc_text(metadata.get("DeletionDate")),
                "enabled": metadata.get("Enabled"),
                "multi_region": metadata.get("MultiRegion", False),
                "pending_deletion": metadata.get("KeyState") == "PendingDeletion",
            }
        )

        try:
            record["tags"] = key_tags(kms, key_id)
        except ClientError as error:
            append_error(record, f"ListResourceTags failed: {error}")

        supported, enabled, period, next_date, rotation_error = rotation_details(
            kms, key_id, metadata
        )
        record.update(
            {
                "rotation_supported": supported,
                "rotation_enabled": enabled,
                "rotation_period_days": period,
                "next_rotation_date": next_date,
            }
        )
        if rotation_error:
            append_error(record, rotation_error)

    except (ClientError, BotoCoreError) as error:
        append_error(record, f"DescribeKey failed: {error}")

    return record


def collect_account(snapshot_time, account):
    account_id = account["account_id"]
    account_name = account["account_name"]

    try:
        credentials = assume_member_role(account_id)
    except (ClientError, BotoCoreError) as error:
        return [empty_record(snapshot_time, account_id, account_name, None,
                             f"AssumeRole failed: {error}")]

    try:
        regions = enabled_regions(credentials)
    except (ClientError, BotoCoreError) as error:
        return [empty_record(snapshot_time, account_id, account_name, None,
                             f"DescribeRegions failed: {error}")]

    records = []
    for region in regions:
        try:
            kms = assumed_client("kms", region, credentials)
            aliases_by_key = alias_map(kms)
            for item in all_keys(kms):
                key_id = item["KeyId"]
                records.append(
                    collect_key(
                        kms,
                        snapshot_time,
                        account_id,
                        account_name,
                        region,
                        key_id,
                        aliases_by_key.get(key_id, []),
                    )
                )
        except (ClientError, BotoCoreError) as error:
            records.append(
                empty_record(snapshot_time, account_id, account_name, region,
                             f"Region collection failed: {error}")
            )
    return records


def ndjson(records):
    return "\n".join(
        json.dumps(item, separators=(",", ":"), ensure_ascii=False, default=str)
        for item in records
    ) + "\n"


def write_inventory(records, collection_time):
    body = ndjson(records).encode("utf-8")
    history_key = (
        f"history/year={collection_time:%Y}/month={collection_time:%m}/"
        f"day={collection_time:%d}/kms-inventory-{collection_time:%Y%m%dT%H%M%SZ}.json"
    )
    common = {
        "Bucket": CENTRAL_BUCKET,
        "Body": body,
        "ContentType": "application/x-ndjson",
        "ServerSideEncryption": "AES256",
    }
    S3.put_object(Key=CURRENT_OBJECT_KEY, **common)
    S3.put_object(Key=history_key, **common)
    return history_key


def lambda_handler(event, context):
    collection_time = datetime.now(timezone.utc)
    snapshot_time = utc_text(collection_time)

    for account in TARGET_ACCOUNTS:
        account_id = account.get("account_id", "")
        if not account_id.isdigit() or len(account_id) != 12:
            raise ValueError(
                "Replace REPLACE_WITH_12_DIGIT_ACCOUNT_ID with a real 12-digit AWS account ID."
            )

    records = []
    summaries = []
    for account in TARGET_ACCOUNTS:
        account_records = collect_account(snapshot_time, account)
        records.extend(account_records)
        summaries.append(
            {
                "account_id": account["account_id"],
                "account_name": account["account_name"],
                "record_count": len(account_records),
                "error_count": sum(
                    1 for item in account_records if item.get("collection_error")
                ),
            }
        )

    if not records:
        raise RuntimeError("No inventory records were produced.")

    history_key = write_inventory(records, collection_time)
    return {
        "statusCode": 200,
        "message": "KMS inventory collection completed.",
        "snapshot_time": snapshot_time,
        "bucket": CENTRAL_BUCKET,
        "current_object": CURRENT_OBJECT_KEY,
        "history_object": history_key,
        "account_count": len(TARGET_ACCOUNTS),
        "inventory_record_count": len(records),
        "collection_error_count": sum(
            1 for item in records if item.get("collection_error")
        ),
        "accounts": summaries,
    }
